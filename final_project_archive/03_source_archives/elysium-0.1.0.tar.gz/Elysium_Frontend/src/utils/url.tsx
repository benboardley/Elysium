export const url: string = 'http://ec2-18-219-133-202.us-east-2.compute.amazonaws.com:8000/';
//export const url: string = 'http://localhost:8000/';