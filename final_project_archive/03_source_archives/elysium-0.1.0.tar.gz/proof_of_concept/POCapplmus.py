import os
from dotenv import load_dotenv

class POCapplmus:
    def __init__(self):
        self.none = None
    
