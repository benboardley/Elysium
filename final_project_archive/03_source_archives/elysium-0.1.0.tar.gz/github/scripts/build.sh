#!/bin/bash
set -xe