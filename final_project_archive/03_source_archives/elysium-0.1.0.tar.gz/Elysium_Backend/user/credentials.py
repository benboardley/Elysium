import os

CLIENT_ID = os.environ["client_id"]
CLIENT_SECRET = os.environ["client_secret"]
REDIRECT_URI = os.environ["redirect_uri"]